#!/bin/sh

export SRVDIR="/panfs/users/schan15/server"
export NSERVER="32"
export HOSTLIST="hostlists/srv_hostlist${NSERVER}"
export TB=TB5

. ${PWD}/srv_env.sh

cd ${SRVDIR}
pwd
clush --hostfile=${HOSTLIST} "export TB=${TB}; export SRVDIR=${SRVDIR}; cd ${SRVDIR}; ./clean_server.sh"
echo "Clean - DONE"
clush --hostfile=${HOSTLIST} "export TB=${TB}; export SRVDIR=${SRVDIR}; cd ${SRVDIR}; ./start_server.sh"
echo "Start - DONE"
