#!/bin/sh

rm -rf serverlogs
mkdir serverlogs
export HOSTLIST=srv_hostlist2

clush --hostfile=/home/schan15/work/server/$HOSTLIST "mkdir -p /home/schan15/work/client/serverlogs/\`hostname\`; cp /tmp/daos_*.log /home/schan15/work/client/serverlogs/\`hostname\`/" &
