#!/bin/sh

export RUNDIR="/panfs/users/schan15/client"
export BUILDDIR="/panfs/users/schan15/builds"
export TB=TB5
export MOUNTDIR="/tmp/daos/${USER}"
export APPSRC="/panfs/users/schan15/apps/vpic_small/vpic-install"
export APPRUNDIR="${MOUNTDIR}/vpic-install"
export TESTCMD="${MOUNTDIR}/vpic-install/harris.Linux"
export PPN=4
export IL=0
export MOUNT_DFUSE=1

cd $RUNDIR

export RF=0
export TEST="VPIC_SMALL_1to4"
for n in {2,4}
do
  export NSERVER="${n}"
  export NCLIENT="$((${NSERVER}*4))"
  export RANKS="0-$((${NSERVER}-1))"
  export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
  export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
  export RUNLOG="${TESTDIR}.log"

  rm -rf ${RESULTDIR}
  mkdir -p ${RESULTDIR}

  ${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}
done

export RF=2
export TEST="VPIC_SMALL_1to4"
for n in {4,}
do
  export NSERVER="${n}"
  export NCLIENT="$((${NSERVER}*4))" 
  export RANKS="0-$((${NSERVER}-1))"
  export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
  export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
  export RUNLOG="${TESTDIR}.log"

  rm -rf ${RESULTDIR}
  mkdir -p ${RESULTDIR}

  ${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}
done

export RF=0
export TEST="VPIC_SMALL_c16"
for n in {2,4,8,16,32}
do
  export NSERVER="${n}"
  export NCLIENT="16"
  export RANKS="0-$((${NSERVER}-1))"
  export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
  export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
  export RUNLOG="${TESTDIR}.log"

  rm -rf ${RESULTDIR}
  mkdir -p ${RESULTDIR}

  ${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}
done

export RF=2
export TEST="VPIC_SMALL_c16"
for n in {8,16,32} #add 4 when DAOS-8262 is fixed
do
  export NSERVER="${n}"
  export NCLIENT="16"
  export RANKS="0-$((${NSERVER}-1))"
  export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
  export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
  export RUNLOG="${TESTDIR}.log"

  rm -rf ${RESULTDIR}
  mkdir -p ${RESULTDIR}

  ${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}
done

