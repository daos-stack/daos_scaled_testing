#!/bin/sh

export RUNDIR="/panfs/users/schan15/client"
export BUILDDIR="/panfs/users/schan15/builds"
export TB=TB5
export MOUNTDIR="/tmp/daos/${USER}"
export APPSRC="/panfs/users/schan15/apps/efi_johann"
export APPINFILE="${RUNDIR}/input/e2vp2.cfg.small"
export APPINFILEDEST="${MOUNTDIR}/efi_johann/test/e2vp2.cfg"
export APPRUNDIR="${MOUNTDIR}/efi_johann/test"
export TESTCMD="${MOUNTDIR}/efi_johann/bin/efispec3d_1.0_avx512_async.exe"
export PPN=8
export MOUNT_DFUSE=1

cd $RUNDIR

export RF=0
export IL=0
export TEST="EFISPEC_1to4"
for n in {8,}
do
  export NSERVER="${n}"
  export NCLIENT="$((${NSERVER}*4))"
  export RANKS="0-$((${NSERVER}-1))"
  export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
  export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
  export RUNLOG="${TESTDIR}.log"

  rm -rf ${RESULTDIR}
  mkdir -p ${RESULTDIR}

  ${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}
done

