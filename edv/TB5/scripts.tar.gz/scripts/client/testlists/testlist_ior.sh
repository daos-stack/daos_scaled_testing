#!/bin/sh

export RUNDIR="/panfs/users/schan15/client"
export BUILDDIR="/panfs/users/schan15/builds"
export MOUNTDIR="/tmp/daos/${USER}"
export TB=TB5

cd $RUNDIR

export TEST="IOR"
export PPN=1
export NCLIENT="1"
export NSERVER="2"

export RF=0
export IL=0
export TESTDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
export RESULTDIR="${RUNDIR}/results/${TESTDIR}"
export RUNLOG="${TESTDIR}.log"

export MOUNT_DFUSE=0

rm -rf ${RESULTDIR}
mkdir -p ${RESULTDIR}
export SWFILEWRITE="${RESULTDIR}/sw_wr"
rm -f ${SWFILEWRITE}
export SWFILEREAD="${RESULTDIR}/sw_rd"
rm -f ${SWFILEREAD}

${RUNDIR}/scripts/run_client.sh 2>&1 | tee ${RESULTDIR}/${RUNLOG}

