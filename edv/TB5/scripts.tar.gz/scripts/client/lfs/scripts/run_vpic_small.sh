#/bin/sh

. /opt/intel/impi/2021.2.0.215/setvars.sh --force
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/ofed/CURRENT/lib64/libibverbs

rm -rf /lfs/lfs12/schan15/vpic-install
cp -r /home/schan15/work/apps/vpic_small/vpic-install/ /lfs/lfs12/schan15
cd /lfs/lfs12/schan15/vpic-install
echo VPIC files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

#vpic small
mpiexec -n 32 --hostfile /lfs/lfs12/schan15/nodefile -ppn 4 /lfs/lfs12/schan15/vpic-install/harris.Linux 2>&1

echo VPIC files after run
ls | wc -l
echo Disk usage after run
du -sh
echo
