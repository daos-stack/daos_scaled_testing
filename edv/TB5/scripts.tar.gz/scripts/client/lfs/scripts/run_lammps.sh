#/bin/sh

. /opt/intel/impi/2021.2.0.215/setvars.sh --force
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/ofed/CURRENT/lib64/libibverbs

rm -rf /lfs/lfs12/schan15/lammps
cp -r /home/schan15/work/apps/lammps /lfs/lfs12/schan15
cd /lfs/lfs12/schan15/lammps
cp /home/schan15/work/client/lfs/scripts/in.lj ./bench/in.lj
echo LAMMPS files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

mpiexec -n 128 --hostfile /lfs/lfs12/schan15/nodefile -ppn 4 src/lmp_mpi -i ./bench/in.lj 2>&1

echo LAMMPS files after run
ls | wc -l
echo Disk usage after run
du -sh
echo
