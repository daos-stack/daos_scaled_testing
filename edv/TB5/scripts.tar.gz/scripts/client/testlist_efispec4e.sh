#!/bin/sh

cd /home/schan15/work/client

export TEST="EFISPEC_BIG"
export PPN=8
export NCLIENT=16
export NSERVER="4"

#export RF=0
#export IL=0
#export runDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
#export runLOG="${runDIR}.log"

#mkdir ${runDIR}

#./run_client.sh 2>&1 | tee ${runDIR}/${runLOG}

export RF=0
export IL=1
export runDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
export runLOG="${runDIR}.log"

mkdir ${runDIR}

./run_client.sh 2>&1 | tee ${runDIR}/${runLOG}

#export RF=2
#export IL=0
#export runDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
#export runLOG="${runDIR}.log"

#mkdir ${runDIR}

#./run_client.sh 2>&1 | tee ${runDIR}/${runLOG}

#export RF=2
#export IL=1
#export runDIR="${TEST}_${NSERVER}e_${NCLIENT}c_${PPN}ppn_RF${RF}_IL${IL}"
#export runLOG="${runDIR}.log"

#mkdir ${runDIR}

#./run_client.sh 2>&1 | tee ${runDIR}/${runLOG}

