#!/bin/sh

echo START time
date

export TB=TB5

export SCM="700G" #700G
export NVME="1T" #1T
export SRV_HOSTLIST="/panfs/users/schan15/server/srv_hostlist$NSERVER"
export CLI_HOSTLIST="/panfs/users/schan15/client/nodefile"
export LAMMPS_IN="/panfs/users/schan15/client/in.lj"
export EFISPEC_IN="/panfs/users/schan15/client/$TB/e2vp2.cfg"
export envIL=""
export NPROCESS=$(( $NCLIENT * $PPN ))
export PLABEL="edv_pool$NSERVER"

#export EXTRA_ENV="-env D_POOL_WARMUP=1" #!!!! if use this, set env in client_env !!! #
export EXTRA_ENV=""

export MOUNT_DFUSE=1
runVPIC=0
runLAMMPS=0
runEFISPEC=1
runIOR=0
runIORdfs=0

echo NPROCESS=$NPROCESS

echo "Sourcing env"
if [ "$runEFISPEC" == "1" ]; then
  . /opt/intel/oneAPI/latest/setvars.sh
fi
. /opt/intel/impi/2021.2.0.215/setvars.sh --force
. /panfs/users/schan15/client/client_env.sh

#Using MPICH
#export PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/bin:$PATH
#export LD_LIBRARY_PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/lib:$LD_LIBRARY_PATH

source ./setup.sh

cd /tmp/daos/schan15/
rm -f testfile
rm -rf vpic-install
rm -rf lammps

if [ "$IL" == "1" ]; then
  export envIL=" -env LD_PRELOAD=/panfs/users/schan15/builds/$TB/CLIENT/install/lib64/libioil.so -env D_IL_REPORT=5 -env D_LOG_MASK=INFO"
fi

if [ "$runVPIC" == "1" ]; then
  cp -r ~/work/apps/vpic/vpic-install/ .
  cd vpic-install/

  echo Pool query before run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo VPIC files before run
  ls | wc -l
  echo Disk usage before run
  du -sh
  echo

  echo "RUNNING:"
  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/vpic-install/harris.Linux"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/vpic-install/harris.Linux 2>&1

  echo Pool query after run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo VPIC files after run
  ls | wc -l
  echo Disk usage after run
  du -sh
  echo
  rm -rf /tmp/daos/schan15/vpic-install
fi

if [ "$runLAMMPS" == "1" ]; then
  cp -r ~/work/apps/lammps/ .
  cd lammps
  cp $LAMMPS_IN ./bench/

  echo Pool query before run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo LAMMPS files before run
  ls | wc -l
  echo Disk usage before run
  du -sh
  echo

  echo "RUNNING:"
  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN ./src/lmp_mpi -i ./bench/in.lj"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN ./src/lmp_mpi -i ./bench/in.lj 2>&1

  echo Pool query after run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo LAMMPS files after run
  ls | wc -l
  echo Disk usage after run
  du -sh
  echo
  rm -rf /tmp/daos/schan15/lammps/
fi

if [ "$runEFISPEC" == "1" ]; then
  cp -r ~/work/apps/efi_johann/ .
  cd efi_johann/test
  rm -f /panfs/users/schan15/client/${runDIR}/e2vp2.lst
  cp $EFISPEC_IN .

  #. /opt/intel/oneAPI/latest/setvars.sh
  #. /panfs/users/schan15/client/client_env.sh

  pwd
  ls ../bin/efispec3d_1.0_avx512_async.exe

  echo Pool query before run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo EFISPEC files before run
  ls | wc -l
  echo Disk usage before run
  du -sh
  echo

  echo "RUNNING:"
  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe 2>&1
  cp e2vp2.lst /panfs/users/schan15/client/${runDIR}

  echo Pool query after run
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL
  echo EFISPEC files after run
  ls | wc -l
  echo Disk usage after run
  du -sh
  echo

  echo Deleting files
  date
  rm -rf /tmp/daos/schan15/efi_johann/
  echo Done 
  date
fi


if [ "$runIOR" == "1" ]; then
  echo
  echo "RUNNING:"
  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile 2>&1
  echo
  ls -al /tmp/daos/schan15/testfile
fi

if [ "$runIORdfs" == "1" ]; then
  echo
  echo "RUNNING:"
  #echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX"
  #echo
  #mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX 2>&1
  #echo

  rm -f /panfs/users/schan15/client/sw

  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -a DFS -b 150G -C -e -w -W -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=/panfs/users/schan15/client/sw -D 60 -d 5 -t 1M --dfs.cont $CONT --dfs.group daos_server --dfs.pool $POOL --dfs.oclass SX --dfs.chunk_size 1M -v"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -a DFS -b 150G -C -e -w -W -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=/panfs/users/schan15/client/sw -D 60 -d 5 -t 1M --dfs.cont $CONT --dfs.group daos_server --dfs.pool $POOL --dfs.oclass SX --dfs.chunk_size 1M -v
  echo

  echo Pool query after IOR write
  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL

  echo "mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -a DFS -b 150G -C -Q 1 -e -r -R -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=/panfs/users/schan15/client/sw -D 60 -d 5 -t 1M --dfs.cont $CONT --dfs.group daos_server --dfs.pool $POOL --dfs.oclass SX --dfs.chunk_size 1M -v"
  echo
  mpiexec $EXTRA_ENV $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -a DFS -b 150G -C -Q 1 -e -r -R -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=/panfs/users/schan15/client/sw -D 60 -d 5 -t 1M --dfs.cont $CONT --dfs.group daos_server --dfs.pool $POOL --dfs.oclass SX --dfs.chunk_size 1M -v
  echo

  dmg -o /panfs/users/schan15/client/daos_control.yml pool query $PLABEL

  dfuse -m /tmp/daos/schan15 --pool $PLABEL --cont $CONT --disable-caching
  ls -al /tmp/daos/schan15
  rm -f /tmp/daos/schan15/testfile
  #ls -al /tmp/daos/schan15/testfile
fi

cd /panfs/users/schan15/client

echo
echo "Copying clientlogs"
echo

rm -rf ${runDIR}/clientlogs
mkdir -p ${runDIR}/clientlogs

clush --hostfile=$CLI_HOSTLIST "mkdir -p /home/schan15/work/client/${runDIR}/clientlogs/\`hostname\`; cp /tmp/daos_agent-schan15/daos_client.log /home/schan15/work/client/${runDIR}/clientlogs/\`hostname\`/"

echo
echo "Copying serverlogs"
echo

rm -rf ${runDIR}/serverlogs
mkdir -p ${runDIR}/serverlogs
chmod 777 ${runDIR}/serverlogs

clush --user=daos_server --hostfile=$SRV_HOSTLIST "export TB=$TB; cd /panfs/users/schan15/server; source srv_env.sh; daos_metrics -S 0 --csv > /tmp/daos_metrics_0.csv; daos_metrics -S 1 --csv > /tmp/daos_metrics_1.csv; dmesg > /tmp/daos_dmesg.txt"

clush --user=daos_server --hostfile=$SRV_HOSTLIST "mkdir -p /home/schan15/work/client/${runDIR}/serverlogs/\`hostname\`; cp /tmp/daos_*.* /home/schan15/work/client/${runDIR}/serverlogs/\`hostname\`/; chmod -R 777 /home/schan15/work/client/${runDIR}/serverlogs/\`hostname\`/"

./unmount.sh

dmg -o /panfs/users/schan15/client/daos_control.yml pool destroy $POOL

echo END time
date
