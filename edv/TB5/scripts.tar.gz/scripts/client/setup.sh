#!/bin/sh

echo "Unmounting"
./unmount.sh
echo


rm daos_server.attach_info_tmp
echo "Number of Client nodes"
cat nodefile | wc -l
echo

echo
echo Running $TB
which daos_agent
echo

echo "Cleaning Agent"
clush --hostfile=nodefile "export TB=$TB; cd /panfs/users/schan15/client; source client_env.sh; ./clean_agent.sh" &
sleep 5
echo

echo "Starting Agent"
clush --hostfile=nodefile "export TB=$TB; cd /panfs/users/schan15/client; source client_env.sh; ./start_agent.sh" &
sleep 5
echo

echo "Dumping attach info"
daos_agent -i -o daos_agent.yml dump-attachinfo -o  daos_server.attach_info_tmp
cat daos_server.attach_info_tmp
echo

echo "Creating Pool"
echo "dmg -o ./daos_control.yml pool create -s $SCM -n $NVME -p $PLABEL"
POOL=`dmg -o ./daos_control.yml pool create -s $SCM -n $NVME -p $PLABEL | grep "UUID" |  awk '{print $3}'`
echo $POOL
export POOL=$POOL
dmg -o ./daos_control.yml pool query $PLABEL
echo

echo "Creating Container"
echo "daos cont create --pool=$PLABEL --type POSIX --properties=rf:${RF} --sys-name=daos_server"
CONT=`daos cont create --pool=$PLABEL --type POSIX --properties=rf:${RF} --sys-name=daos_server | grep "UUID" | awk '{print $4}'`
export CONT=$CONT
echo $CONT
echo

daos cont get-prop --cont=$CONT --pool=$PLABEL

clush --hostfile=nodefile "rm -rf /tmp/daos/schan15; mkdir -p /tmp/daos/schan15"

if [ "$MOUNT_DFUSE" == "1" ]; then
  echo "Mounting Dfuse"
  clush --hostfile=nodefile "export TB=$TB; export PLABEL=$PLABEL; export CONT=$CONT; /panfs/users/schan15/client/mount_dfuse.sh"
  echo
fi

