#!/bin/sh

clush --hostfile=${CLI_HOSTLIST} "fusermount -u /tmp/daos/${USER}"
clush --hostfile=${CLI_HOSTLIST} "killall -9 dfuse"
clush --hostfile=${CLI_HOSTLIST} "killall -9 daos_agent"
clush --hostfile=${CLI_HOSTLIST} "fusermount -u /tmp/daos/${USER}"
