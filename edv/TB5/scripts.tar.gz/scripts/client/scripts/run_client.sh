#!/bin/sh

echo START time
date

export SCM="700G" #700G
export NVME="1T" #1T
export SRV_HOSTLIST="${RUNDIR}/../server/hostlists/srv_hostlist${NSERVER}"
export CLI_HOSTLIST="${RUNDIR}/hostlists/cli_hostlist${NCLIENT}"
export envIL=""
export NPROCESS=$(( $NCLIENT * $PPN ))
export PLABEL="${TESTDIR}"

#export EXTRA_ENV="-env D_POOL_WARMUP=1" #!!!! if use this, set env in client_env !!! #
export EXTRA_ENV=""

echo NPROCESS=${NPROCESS}

echo "Sourcing env"
if [[ "$TEST" =~ "EFISPEC" ]]; then
  . /opt/intel/oneAPI/latest/setvars.sh
fi
. /opt/intel/impi/2021.2.0.215/setvars.sh --force
. ${RUNDIR}/scripts/client_env.sh

echo "Unmounting"
${RUNDIR}/scripts/unmount.sh
echo

rm ${RESULTDIR}/daos_server.attach_info_tmp
echo "Number of Client nodes"
cat ${CLI_HOSTLIST} | wc -l
echo

echo
echo Running $TB
which daos_agent
echo

echo "Cleaning Agent"
clush --hostfile=${CLI_HOSTLIST} "export TB=$TB; export RUNDIR=${RUNDIR}; cd ${RUNDIR}/scripts; source client_env.sh; ./clean_agent.sh" &
sleep 5
echo

echo "Starting Agent"
clush --hostfile=${CLI_HOSTLIST} "export TB=$TB; export RUNDIR=${RUNDIR}; cd ${RUNDIR}/scripts; source client_env.sh; ./start_agent.sh" &
sleep 5
echo

echo "Dumping attach info"
daos_agent -i -o ${RUNDIR}/scripts/daos_agent-${USER}.yml dump-attachinfo -o  ${RESULTDIR}/daos_server.attach_info_tmp
cat ${RESULTDIR}/daos_server.attach_info_tmp
echo

echo "Creating Pool"
CMD="dmg -o ${RUNDIR}/scripts/daos_control.yml pool create -s ${SCM} -n ${NVME} -p ${PLABEL} -r=${RANKS}"
echo ${CMD}
OUT="$(eval ${CMD})"
RC=$?
if [[ ${RC} -ne 0 ]]; then
  echo Pool create failed
  killall daos_agent
  killall clush
  exit 1
fi
echo ${OUT}
POOL=$(echo ${OUT} | grep "UUID" | cut -d ':' -f 3 | sed 's/^[ \t]*//;s/[ \t]*$//' | awk '{print $1}')
echo POOL is ${POOL}
export POOL=${POOL}
dmg -o ${RUNDIR}/scripts/daos_control.yml pool query ${PLABEL}
echo

echo "Creating Container"
export CONT=$(uuidgen)
CMD="daos cont create --pool=${PLABEL} --cont=$CONT --type POSIX --properties=rf:${RF} --sys-name=daos_server"
echo ${CMD}
OUT="$(eval ${CMD})"
RC=$?
if [[ ${RC} != 0 ]]; then
  echo Container create failed
  killall daos_agent
  killall clush
  exit 1
fi
echo ${OUT}
echo

daos cont get-prop --cont=${CONT} --pool=${PLABEL}

clush --hostfile=${CLI_HOSTLIST} "rm -rf /tmp/daos/${USER}; mkdir -p /tmp/daos/${USER}"

if [ "$MOUNT_DFUSE" == "1" ]; then
  echo "Mounting Dfuse"
  clush --hostfile=${CLI_HOSTLIST} "export TB=${TB}; export RUNDIR=${RUNDIR}; export PLABEL=${PLABEL}; export CONT=${CONT}; export MOUNTDIR=${MOUNTDIR}; ${RUNDIR}/scripts/mount_dfuse.sh"

  if [[ ! -d ${MOUNTDIR} ]]; then
    echo Dfuse mount unsuccessful!!
    killall daos_agent
    killall clush
    exit 1
  fi

  echo
fi

#mkdir -p ${MOUNTDIR}/vpic
#if [[ -d "${MOUNTDIR}/vpic" ]]; then
#  echo "${MOUNTDIR}/vpic" exists
#fi

if [[ "$IL" == "1" ]]; then
  export envIL=" -env LD_PRELOAD=${BUILDDIR}/${TB}/CLIENT/install/lib64/libioil.so -env D_IL_REPORT=5 -env D_LOG_MASK=INFO"
fi

echo

if [[ "${TEST}" =~ "IOR" ]]; then
  export IORWRITECMD="${RUNDIR}/../apps/ior/install/bin/ior -a DFS -b 150G -C -e -w -W -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=${SWFILEWRITE} -D 60 -d 5 -t 1M --dfs.cont ${CONT} --dfs.group daos_server --dfs.pool ${POOL} --dfs.oclass SX --dfs.chunk_size 1M -v"

  export IORREADCMD="${RUNDIR}/../apps/ior/install/bin/ior -a DFS -b 150G -C -Q 1 -e -r -R -g -G 27 -k -i 1 -s 1 -o /testFile -O stoneWallingWearOut=1 -O stoneWallingStatusFile=${SWFILEREAD} -D 60 -d 5 -t 1M --dfs.cont ${CONT} --dfs.group daos_server --dfs.pool ${POOL} --dfs.oclass SX --dfs.chunk_size 1M -v"

  export TESTCMD=${IORWRITECMD}
else
  cp -r ${APPSRC} ${MOUNTDIR}
  #cp -r ${APPSRC} ${LFSDIR}
  if [[ ! -z "${APPINFILE}" ]]; then
    cp -f ${APPINFILE} ${APPINFILEDEST}
  fi
  cd ${APPRUNDIR}
fi

echo Files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

echo "RUNNING:"
#I_MPI_DEBUG=4 mpirun -n ${NPROCESS} --hostfile ${CLI_HOSTLIST} -ppn ${PPN} -genv I_MPI_PIN_PROCESSOR_LIST=0-7 ${TESTCMD}
echo "mpiexec ${EXTRA_ENV} ${envIL} -n ${NPROCESS} --hostfile ${CLI_HOSTLIST} -ppn ${PPN} ${TESTCMD}"
echo
mpiexec ${EXTRA_ENV} ${envIL} -n ${NPROCESS} --hostfile ${CLI_HOSTLIST} -ppn ${PPN} ${TESTCMD}
echo

echo Pool query after ${TEST}
dmg -o ${RUNDIR}/scripts/daos_control.yml pool query $PLABEL

echo 

if [[ "${TEST}" =~ "IOR" ]]; then
  ${RUNDIR}/scripts/mount_dfuse.sh
  if [[ ! -d ${MOUNTDIR} ]]; then
    echo Dfuse mount unsuccessful!!
    killall daos_agent
    killall clush
    exit 1
  else
    ls -al ${MOUNTDIR}
  fi
fi

if [[ "${TEST}" =~ "EFISPEC" ]]; then
  cp e2vp2.lst ${RESULTDIR}
fi

echo

echo Files after run
ls | wc -l
echo Disk usage after run
du -sh
echo

echo
echo "Copying clientlogs"
echo

rm -rf ${RESULTDIR}/clientlogs
mkdir -p ${RESULTDIR}/clientlogs

clush --hostfile=${CLI_HOSTLIST} "mkdir -p ${RESULTDIR}/clientlogs/\`hostname\`; cp /tmp/daos_agent-${USER}/daos_client.log ${RESULTDIR}/clientlogs/\`hostname\`/"

echo
echo "Copying serverlogs"
echo

rm -rf ${RESULTDIR}/serverlogs
mkdir -p ${RESULTDIR}/serverlogs
chmod 777 ${RESULTDIR}/serverlogs

clush --user=daos_server --hostfile=${SRV_HOSTLIST} "export TB=${TB}; cd ${RUNDIR}/../server; source srv_env.sh; daos_metrics -S 0 --csv > /tmp/daos_metrics_0.csv; daos_metrics -S 1 --csv > /tmp/daos_metrics_1.csv; dmesg > /tmp/daos_dmesg.txt"

clush --user=daos_server --hostfile=${SRV_HOSTLIST} "mkdir -p ${RESULTDIR}/serverlogs/\`hostname\`; cp /tmp/daos_*.* ${RESULTDIR}/serverlogs/\`hostname\`/; chmod -R 777 ${RESULTDIR}/serverlogs/\`hostname\`/"

cd ${RUNDIR}

echo Deleting files
date
rm -rf ${MOUNTDIR}/*
echo Done
date
echo

echo Unmounting
${RUNDIR}/scripts/unmount.sh

echo "Destroying Pool"
CMD="dmg -o ${RUNDIR}/scripts/daos_control.yml pool destroy ${PLABEL}"
echo ${CMD}
OUT="$(eval ${CMD})"
RC=$?
if [[ ${RC} -ne 0 ]]; then
  echo Pool destroy failed
  killall daos_agent
  killall clush
  exit 1
fi
echo ${OUT}

echo END time
date
