#!/bin/bash

source /panfs/users/schan15/server/srv_env.sh
daos_server -o /panfs/users/schan15/server/daos_server.yml start --recreate-superblocks
