#!/bin/bash

source /panfs/users/schan15/server/srv_env.sh
pkill -9 daos
rm -rf /mnt/daos0/*
rm -rf /mnt/daos1/*
rm -rf /dev/hugepages/spdk*
rm -rf /tmp/daos_server
mkdir -p /tmp/daos_server
rm -f /tmp/daos_control.log /tmp/daos_io0.log /tmp/daos_io1.log /tmp/daos_metric.csv
daos_ssd -o /panfs/users/schan15/server/daos_server_clean.yml format <<< yes
