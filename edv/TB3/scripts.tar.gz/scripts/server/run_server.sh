#!/bin/sh

export HOSTLIST=srv_hostlist2

cd /panfs/users/schan15/server
pwd
clush --hostfile=$HOSTLIST "cd /panfs/users/schan15/server; ./clean_server.sh"
echo "Clean - DONE"
sleep 30
clush --hostfile=$HOSTLIST "cd /panfs/users/schan15/server; ./start_server.sh"
echo "Start - DONE"
