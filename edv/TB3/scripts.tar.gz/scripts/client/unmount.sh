#!/bin/sh

clush --hostfile=nodefile "fusermount -u /tmp/daos/schan15"
clush --hostfile=nodefile "killall -9 dfuse"
clush --hostfile=nodefile "killall -9 daos_agent"
clush --hostfile=nodefile "fusermount -u /tmp/daos/schan15"
