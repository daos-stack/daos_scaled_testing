#!/bin/sh

export RF=0
export SCM="600G"
export NVME="1T"

echo "Unmounting"
./unmount.sh
echo


rm daos_server.attach_info_tmp
echo "Number of Client nodes"
cat nodefile | wc -l
echo

echo "Sourcing env"
#. /opt/intel/impi/2021.2.0.215/setvars.sh
. /panfs/users/schan15/client/client_env.sh
export PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/bin:$PATH
export LD_LIBRARY_PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/lib:$LD_LIBRARY_PATH
echo

echo "Cleaning Agent"
clush --hostfile=nodefile "cd /panfs/users/schan15/client; source client_env.sh; ./clean_agent.sh" &
sleep 1
echo

echo "Starting Agent"
clush --hostfile=nodefile "cd /panfs/users/schan15/client; source client_env.sh; ./start_agent.sh" &
sleep 1
echo

echo "Dumping attach info"
daos_agent -i -o daos_agent.yml dump-attachinfo -o  daos_server.attach_info_tmp
cat daos_server.attach_info_tmp
echo

echo "Creating Pool"
POOL=`dmg -o ./daos_control.yml pool create -s $SCM -n $NVME | grep "UUID" |  awk '{print $3}'`
echo $POOL
export POOL=$POOL
dmg -o ./daos_control.yml pool query $POOL
echo

echo "Creating Container"
CONT=`daos cont create --pool=$POOL  --type POSIX --properties=rf:${RF} --sys-name=daos_server | grep "UUID" | awk '{print $4}'`
export CONT=$CONT
echo $CONT
echo

daos cont get-prop --cont=$CONT --pool=$POOL

echo "Mounting Dfuse"
clush --hostfile=nodefile "rm -rf /tmp/daos/schan15; mkdir -p /tmp/daos/schan15" & 
sleep 1
clush --hostfile=nodefile "export POOL=$POOL; export CONT=$CONT; /panfs/users/schan15/client/mount_dfuse.sh" &
sleep 1
echo

