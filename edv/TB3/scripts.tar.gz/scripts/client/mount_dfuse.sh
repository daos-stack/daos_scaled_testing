#!/bin/sh

source /panfs/users/schan15/client/client_env.sh
#export POOL=1908101f-01d8-47e4-9c1a-f7f8c09634be
#export CONT=c604da57-5244-478a-b048-0d8ae8690e6c
dfuse -m /tmp/daos/schan15 --pool $POOL --cont $CONT --disable-caching

mount | grep dfuse
