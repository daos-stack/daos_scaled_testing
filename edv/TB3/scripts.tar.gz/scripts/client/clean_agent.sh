#!/bin/bash

source /panfs/users/schan15/client/client_env.sh
pkill -9 daos
rm -rf /tmp/daos_agent-schan15
