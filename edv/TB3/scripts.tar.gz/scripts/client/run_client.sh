#!/bin/sh

#. /opt/intel/impi/2021.2.0.215/setvars.sh
#. /panfs/users/schan15/client/client_env.sh

export SRV_HOSTLIST=srv_hostlist16
export CLI_HOSTLIST="/panfs/users/schan15/client/nodefile"
export NCLI=128
export PPN=8
export envIL=""

runIL=1
runVPIC=0
runLAMMPS=0
runEFISPEC=1
runIOR=0
runIORdfs=0

cd /tmp/daos/schan15/
rm -f testfile
rm -rf vpic-install
rm -rf lammps

if [ "$runIL" == "1" ]; then
  export envIL=" -env LD_PRELOAD=/panfs/users/schan15/builds/TB3/CLIENT/install/lib64/libioil.so -env D_IL_REPORT=5 -env D_LOG_MASK=INFO"
fi

if [ "$runVPIC" == "1" ]; then
  cp -r ~/work/apps/vpic/vpic-install/ .
  cd vpic-install/

  echo VPIC files before run
  ls | wc -l
  echo

  echo "RUNNING:"
  echo "mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN ./harris.Linux"
  echo
  mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN ./harris.Linux

  echo VPIC files after run
  ls | wc -l
  echo
fi

if [ "$runLAMMPS" == "1" ]; then
  cp -r ~/work/apps/lammps/ .
  cd lammps/bench
  cp /panfs/users/schan15/client/tb3/in.lj .

  echo LAMMPS files before run
  ls ../ | wc -l
  echo

  echo "RUNNING:"
  echo "mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN ../src/lmp_mpi -i ./in.lj"
  echo
  mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN ../src/lmp_mpi -i ./in.lj

  echo LAMMPS files after run
  ls ../ | wc -l
  echo
fi

if [ "$runEFISPEC" == "1" ]; then
  cp -r ~/work/apps/efi_johann/ .
  cd efi_johann/test
  rm -f /panfs/users/schan15/client/e2vp2.lst
  cp /panfs/users/schan15/client/tb3/e2vp2.cfg .

  . /opt/intel/oneAPI/latest/setvars.sh
  . /panfs/users/schan15/client/client_env.sh

  pwd
  ls ../bin/efispec3d_1.0_avx512_async.exe

  echo "RUNNING:"
  echo "mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe"
  echo
  mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe
  cp e2vp2.lst /panfs/users/schan15/client/
fi


if [ "$runIOR" == "1" ]; then
  echo
  echo "RUNNING:"
  echo "mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile"
  echo
  mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile
  echo
  ls -al /tmp/daos/schan15/testfile
fi

if [ "$runIORdfs" == "1" ]; then
  echo
  echo "RUNNING:"
  echo "mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX"
  echo
  mpiexec -env OFI_INTERFACE=eib0 -env OFI_DOMAIN=mlx5_0 $envIL -n $NCLI --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX
  echo
  ls -al /tmp/daos/schan15/testfile
fi

cd /panfs/users/schan15/client

echo
echo "Copying clientlogs"
echo

rm -rf clientlogs
mkdir clientlogs

clush --hostfile=$CLI_HOSTLIST "mkdir -p /home/schan15/work/client/clientlogs/\`hostname\`; cp /tmp/daos_agent-schan15/daos_client.log /home/schan15/work/client/clientlogs/\`hostname\`/" &

echo
echo "Copying serverlogs"
echo

rm -rf serverlogs
mkdir serverlogs
chmod 777 serverlogs

clush --user=daos_server --hostfile=/home/schan15/work/server/$SRV_HOSTLIST "cd /panfs/users/schan15/server; source srv_env.sh; daos_metrics -i 1 --csv > /tmp/daos_metrics.csv" &

clush --user=daos_server --hostfile=/home/schan15/work/server/$SRV_HOSTLIST "mkdir -p /home/schan15/work/client/serverlogs/\`hostname\`; cp /tmp/daos_*.* /home/schan15/work/client/serverlogs/\`hostname\`/; chmod -R 777 /home/schan15/work/client/serverlogs/\`hostname\`/" &

./unmount.sh
