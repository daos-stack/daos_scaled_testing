#!/bin/sh

nodes=$(cat /lfs/lfs12/schan15/nodefile)

for node in ${nodes}
do
  clush -w ${node} -u 1 -S "ls /lfs/lfs12/schan15 | wc -l"
  if [[ $? -ne 0 ]]; then
    exit 1
  fi
done
