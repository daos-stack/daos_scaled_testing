#/bin/sh

. /opt/intel/impi/2021.2.0.215/setvars.sh --force
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/ofed/CURRENT/lib64/libibverbs

cd /lfs/lfs12/schan15/vpic_small
echo VPIC files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

#vpic small
mpiexec -n 64 --hostfile /lfs/lfs12/schan15/nodefile -ppn 4 /lfs/lfs12/schan15/vpic_small/vpic-install/harris.Linux 2>&1

#8066 out file (including vpic_small.log)

echo VPIC files after run
ls | wc -l
echo Disk usage after run
du -sh
echo
