#/bin/sh

. /opt/intel/oneAPI/latest/setvars.sh
. /opt/intel/impi/2021.2.0.215/setvars.sh --force
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/ofed/CURRENT/lib64/libibverbs

cd /lfs/lfs12/schan15/efi_johann/test
echo EFI files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

mpiexec  -n 128 --hostfile /lfs/lfs12/schan15/nodefile -ppn 8 /lfs/lfs12/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe 2>&1

echo EFI files after run
ls | wc -l
echo Disk usage after run
du -sh
echo
