#/bin/sh

. /opt/intel/impi/2021.2.0.215/setvars.sh --force
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/ofed/CURRENT/lib64/libibverbs

cd /lfs/lfs12/schan15/vpic_big
echo VPIC files before run
ls | wc -l
echo Disk usage before run
du -sh
echo

#vpic big
mpiexec -n 128 --hostfile /lfs/lfs12/schan15/nodefile -ppn 8 /lfs/lfs12/schan15/vpic_big/vpic-install/harris.Linux 2>&1 

#16130 out file (including vpic_big.log)

echo VPIC files after run
ls | wc -l
echo Disk usage after run
du -sh
echo
