#!/bin/sh

export TB=TB4
export RF=0
export PPN=4
export NCLIENT=16
export NSERVER=16

export SCM="600G"
export NVME="1T"
export SRV_HOSTLIST="/panfs/users/schan15/server/srv_hostlist$NSERVER"
export CLI_HOSTLIST="/panfs/users/schan15/client/nodefile"
export LAMMPS_IN="/panfs/users/schan15/client/$TB/in.lj"
export envIL=""
export NPROCESS=$(( $NCLIENT * $PPN ))
export PLABEL="edv_pool$NSERVER"

echo NPROCESS=$NPROCESS

echo "Sourcing env"
. /opt/intel/impi/2021.2.0.215/setvars.sh
. /panfs/users/schan15/client/client_env.sh

#Using MPICH
#export PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/bin:$PATH
#export LD_LIBRARY_PATH=/home/schan15/work/builds/MPICH/mpich-4.0a2/install/lib:$LD_LIBRARY_PATH

./setup.sh

runIL=0
runVPIC=0
runLAMMPS=1
runEFISPEC=0
runIOR=0
runIORdfs=0

cd /tmp/daos/schan15/
rm -f testfile
rm -rf vpic-install
rm -rf lammps

if [ "$runIL" == "1" ]; then
  export envIL=" -env LD_PRELOAD=/panfs/users/schan15/builds/$TB/CLIENT/install/lib64/libioil.so -env D_IL_REPORT=5 -env D_LOG_MASK=INFO"
fi

if [ "$runVPIC" == "1" ]; then
  cp -r ~/work/apps/vpic/vpic-install/ .
  cd vpic-install/

  echo VPIC files before run
  ls | wc -l
  echo

  echo "RUNNING:"
  echo "mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/vpic-install/harris.Linux"
  echo
  mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/vpic-install/harris.Linux 2>&1

  echo VPIC files after run
  ls | wc -l
  echo
fi

if [ "$runLAMMPS" == "1" ]; then
  cp -r ~/work/apps/lammps/ .
  cd lammps/bench
  cp $LAMMPS_IN .

  echo LAMMPS files before run
  ls ../ | wc -l
  echo

  echo "RUNNING:"
  echo "mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN ../src/lmp_mpi -i ./in.lj"
  echo
  mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN ../src/lmp_mpi -i ./in.lj 2>&1

  echo LAMMPS files after run
  ls ../ | wc -l
  echo
fi

if [ "$runEFISPEC" == "1" ]; then
  cp -r ~/work/apps/efi_johann/ .
  cd efi_johann/test
  rm -f /panfs/users/schan15/client/e2vp2.lst
  cp /panfs/users/schan15/client/tb3/e2vp2.cfg .

  . /opt/intel/oneAPI/latest/setvars.sh
  . /panfs/users/schan15/client/client_env.sh

  pwd
  ls ../bin/efispec3d_1.0_avx512_async.exe

  echo "RUNNING:"
  echo "mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe"
  echo
  mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /tmp/daos/schan15/efi_johann/bin/efispec3d_1.0_avx512_async.exe 2>&1
  cp e2vp2.lst /panfs/users/schan15/client/
fi


if [ "$runIOR" == "1" ]; then
  echo
  echo "RUNNING:"
  echo "mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile"
  echo
  mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a POSIX -t 1m -b 1g -w -r -k -o /tmp/daos/schan15/testfile 2>&1
  echo
  ls -al /tmp/daos/schan15/testfile
fi

if [ "$runIORdfs" == "1" ]; then
  echo
  echo "RUNNING:"
  echo "mpiexec -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX"
  echo
  mpiexec $envIL -n $NPROCESS --hostfile $CLI_HOSTLIST -ppn $PPN /panfs/users/schan15/apps/ior/install/bin/ior -i 5 -a DFS -t 1m -b 1g -w -r -k -o /testfile --dfs.cont=$CONT --dfs.group=daos_server --dfs.pool=$POOL --dfs.oclass=SX 2>&1
  echo
  ls -al /tmp/daos/schan15/testfile
fi

cd /panfs/users/schan15/client

echo
echo "Copying clientlogs"
echo

rm -rf clientlogs
mkdir clientlogs

clush --hostfile=$CLI_HOSTLIST "mkdir -p /home/schan15/work/client/clientlogs/\`hostname\`; cp /tmp/daos_agent-schan15/daos_client.log /home/schan15/work/client/clientlogs/\`hostname\`/" &

echo
echo "Copying serverlogs"
echo

rm -rf serverlogs
mkdir serverlogs
chmod 777 serverlogs

clush --user=daos_server --hostfile=$SRV_HOSTLIST "export TB=$TB; cd /panfs/users/schan15/server; source srv_env.sh; daos_metrics -i 1 --csv > /tmp/daos_metrics.csv" &

clush --user=daos_server --hostfile=$SRV_HOSTLIST "mkdir -p /home/schan15/work/client/serverlogs/\`hostname\`; cp /tmp/daos_*.* /home/schan15/work/client/serverlogs/\`hostname\`/; chmod -R 777 /home/schan15/work/client/serverlogs/\`hostname\`/" &

./unmount.sh
