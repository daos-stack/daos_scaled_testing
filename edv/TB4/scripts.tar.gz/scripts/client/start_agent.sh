#!/bin/sh

#source /opt/crtdc/daos/v1.3.102/centos8/env.sha
source /panfs/users/schan15/client/client_env.sh
#kill -9 168935
rm -rf /tmp/daos_agent-schan15
mkdir -p /tmp/daos_agent-schan15
rm -f daos_server.attach_info_tmp
export HWLOC_HIDE_ERRORS=1
daos_agent -o daos_agent.yml &
#daos_agent -i -o daos_agent.yml dump-attachinfo -o  daos_server.attach_info_tmp
#export POOL=312fbb4f-cfc4-4c6f-80ee-8722ac0089c0
#export CONT=56bc1414-a1ac-4c89-b161-561283d3e368
rm -rf /tmp/daos/$USER
mkdir -p /tmp/daos/$USER
#sleep 2
#dfuse -m /daos/$USER --pool $POOL --cont $CONT
