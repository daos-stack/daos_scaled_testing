#!/bin/sh

export HOSTLIST=srv_hostlist16
export TB=TB4

cd /panfs/users/schan15/server
pwd
clush --hostfile=$HOSTLIST "export TB=$TB; cd /panfs/users/schan15/server; ./clean_server.sh"
echo "Clean - DONE"
clush --hostfile=$HOSTLIST "export TB=$TB; cd /panfs/users/schan15/server; ./start_server.sh"
echo "Start - DONE"
