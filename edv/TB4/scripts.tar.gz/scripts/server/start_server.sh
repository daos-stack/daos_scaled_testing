#!/bin/bash

source /panfs/users/schan15/server/srv_env.sh
echo
which daos_server
echo
daos_server -o /panfs/users/schan15/server/daos_server.yml start --recreate-superblocks
